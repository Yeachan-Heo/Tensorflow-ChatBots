# Tensorflow-ChatBots (version 0.0.1)
Telegram/Slack Chatbot class which can be used as keras custom callback.

# How to Download

## from source(recommended)
### 1.git clone https://github.com/Yeachan-Heo/Tensorflow-ChatBots.git
### 2.python setup.py build
### 3.python setup.py install

## via pip
### 1.pip install Tensorflow-Chatbots

# Telegram Examples
![Alt Image text](/images/telegram_example_1.png?raw=true "example")
![Alt Image text](/images/telegram_example_2.png?raw=true)
![Alt Image text](/images/telegram_example_3.png?raw=true)
# Slack Examples
comming soon!